package com.online.shopping.microservicse.cloudconfigserveranitha;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConfigServerAnithaApplicationTests {

	@Test
	void contextLoads() {
	}

}
