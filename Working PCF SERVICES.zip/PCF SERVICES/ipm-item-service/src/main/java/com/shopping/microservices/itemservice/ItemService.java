package com.shopping.microservices.itemservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.stereotype.Component;


@Component
public class ItemService {

	@Autowired
	ItemRepository itemRepository;
	
	
	public List<Item> getAllItems(){
		return itemRepository.findAll();
	}
	
	public Item getItemByName(String itemName){
		return itemRepository.findByItemName(itemName);	
	}
	
	
}
